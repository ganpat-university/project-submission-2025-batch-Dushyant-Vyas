def pricing(request):
    return render(request, 'pricing.html') 